//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package org.webrtc.audio2.audio;

public interface AudioDeviceModule {
    long getNativeAudioDeviceModulePointer();

    void release();

    void setSpeakerMute(boolean var1);

    void setMicrophoneMute(boolean var1);
}
